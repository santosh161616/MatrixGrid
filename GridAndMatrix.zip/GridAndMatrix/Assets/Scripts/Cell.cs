using TMPro;
using UnityEngine;

// Made the Cell Class to change the value but not using it.
public class Cell : MonoBehaviour
{
    public TMP_Text value;
}